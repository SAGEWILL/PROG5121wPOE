package com.mycompany.prog5121wpoe;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the Login class.
 * Tests cover username validation, password complexity,
 * cell phone number formatting, registration, and login.
 */



public class LoginTest {

    private Login login;

    /**
     * :Set up a Login instance before each test.
     * Using a sample user Kyle first name, as implied by test data.
     */
    @BeforeEach
    public void setUp() {
        login = new Login("Kyle", "Smith");
    }

    // ─────────────────────────────────────────────
    // USERNAME TESTS (assertEquals)
    // ─────────────────────────────────────────────

    /**
     * Test: Username is correctly formatted.
     * Test Data: "kyl_1"
     * Expected: "Username successfully captured."
     */
    @Test
    public void testUsernameCorrectlyFormatted() {
        String result = login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertTrue(result.contains("successfully captured") || result.contains("successfully added"),
                "Expected successful registration messages");
    }

    /**
     * Test: Username is incorrectly formatted (no underscore, too long).
     * Test Data: "kyle!!!!!!!"
     * Expected: Username not correctly formatted message.
     */
    @Test
    public void testUsernameIncorrectlyFormatted() {
        String result = login.registerUser("kyle!!!!!!!", "Ch&&sec@ke99!", "+27838968976");
        assertEquals(
            "Username is not correctly formatted; please ensure that your username " +
            "contains an underscore and is no more than five characters in length.",
            result
        );
    }

    // ─────────────────────────────────────────────
    // PASSWORD TESTS (assertEquals)
    // ─────────────────────────────────────────────

    /**
     * Test: Password meets the complexity requirements.
     * Test Data: "Ch&&sec@ke99!"
     * Expected: "Password successfully captured."
     */
    @Test
    public void testPasswordMeetsComplexityRequirements() {
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"),
                "Password should be valid");
    }

    /**
     * Test: Password does NOT meet the complexity requirements.
     * Test Data: "password"
     * Expected: Password not correctly formatted message.
     */
    @Test
    public void testPasswordDoesNotMeetComplexityRequirements() {
        assertFalse(login.checkPasswordComplexity("password"),
                "Weak password should fail complexity check");
    }

    // ─────────────────────────────────────────────
    // CELL PHONE TESTS (assertEquals)
    // ─────────────────────────────────────────────

    /**
     * Test: Cell phone number is correctly formatted.
     * Test Data: "+27838968976"
     * Expected: "Cell phone number successfully added."
     */
    @Test
    public void testCellPhoneCorrectlyFormatted() {
        assertTrue(login.checkCellPhoneNumber("+27838968976"),
                "Valid SA number should pass");
    }

    /**
     * Test: Cell phone number is incorrectly formatted.
     * Test Data: "08960053"
     * Expected: "Cell number is incorrectly formatted or does not contain international code."
     */
    @Test
    public void testCellPhoneIncorrectlyFormatted() {
        assertFalse(login.checkCellPhoneNumber("08960053"),
                "Number without international code should fail");
    }

    // ─────────────────────────────────────────────
    // LOGIN TESTS (assertTrue/assertFalse)
    // ─────────────────────────────────────────────

    /**
     * Test: Login Successful.
     * Expected: true
     */
    @Test
    public void testLoginSuccessful() {
        // First register the user
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        // Then attempt login with correct credentials
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"),
                "Login should succeed with correct credentials");
    }

    /**
     * Test: Login Failed.
     * Expected: false
     */
    @Test
    public void testLoginFailed() {
        // Register the user first
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        // Attempt login with wrong password
        assertFalse(login.loginUser("kyl_1", "wrongpassword"),
                "Login should fail with incorrect password");
    }

    // ─────────────────────────────────────────────
    // ADDITIONAL VALIDATION TESTS (assertTrue/assertFalse)
    // ─────────────────────────────────────────────

    /**
     * Test: Username correctly formatted — checkUserName returns true.
     */
    @Test
    public void testCheckUserNameTrue() {
        assertTrue(login.checkUserName("kyl_1"),
                "kyl_1 contains underscore and is <=5 chars");
    }

    /**
     * Test: Username incorrectly formatted — checkUserName returns false.
     */
    @Test
    public void testCheckUserNameFalse() {
        assertFalse(login.checkUserName("kyle!!!!!!!"),
                "kyle!!!!!!! has no underscore and is too long");
    }
}
