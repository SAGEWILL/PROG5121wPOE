package com.mycompany.prog5121wpoe;

import java.util.Scanner;

/*
 * This class handles the registration and login features for the app.
 * It checks if the username, password and cell number are valid
 * before allowing the user to register or log in.
 */
public class Login {

    // These variables store the user's details once they register
    private String registeredUsername;
    private String registeredPassword;
    private String registeredCellPhone;
    private String firstName;
    private String lastName;

    /*
     * Constructor - takes the user's first and last name when a Login object is created.
     * I used "this" to make it clear I'm referring to the class variables
     * and not the parameters being passed in.
     */
    public Login(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    /*
     * This method checks if the username is valid.
     * According to the requirements, it must contain an underscore
     * and be no more than 5 characters long.
     * It returns true if both conditions are met, false if not.
     */
    public boolean checkUserName(String username) {
        if (username == null) return false;
        return username.contains("_") && username.length() <= 5;
    }

    /*
     * This method checks if the password is complex enough.
     * The password must be at least 8 characters, have a capital letter,
     * a number, and a special character.
     * I used a for loop to go through each character and check what type it is.
     */
    public boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) return false;

        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;

        // Loop through each character in the password and check its type
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasCapital = true;
            if (Character.isDigit(c)) hasNumber = true;
            if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }

        // All three must be true for the password to pass
        return hasCapital && hasNumber && hasSpecial;
    }

    /*
     * This method validates the cell phone number using regex.
     * I researched how regex works for phone numbers - the pattern checks
     * that the number starts with +27 (SA international code)
     * and is followed by exactly 9 digits.
     *
     * Reference: https://www.regular-expressions.info/phone.html
     */
    public boolean checkCellPhoneNumber(String cellPhoneNumber) {
        if (cellPhoneNumber == null) return false;
        return cellPhoneNumber.matches("^\\+27[0-9]{9}$");
    }

    /*
     * This method handles the full registration process.
     * It calls each of the three check methods above and returns
     * the correct message depending on which check fails.
     * If everything passes, it saves the user's details.
     */
    public String registerUser(String username, String password, String cellPhoneNumber) {
        boolean validUsername = checkUserName(username);
        boolean validPassword = checkPasswordComplexity(password);
        boolean validCell = checkCellPhoneNumber(cellPhoneNumber);

        // Check username first - return error message if it fails
        if (!validUsername) {
            return "Username is not correctly formatted; please ensure that your username " +
                   "contains an underscore and is no more than five characters in length.";
        }

        // Check password next
        if (!validPassword) {
            return "Password is not correctly formatted; please ensure that the password " +
                   "contains at least eight characters, a capital letter, a number, and a special character.";
        }

        // Check cell number last
        if (!validCell) {
            return "Cell number is incorrectly formatted or does not contain international code; " +
                   "please correct the number and try again.";
        }

        // If all checks pass, save the details and confirm registration
        this.registeredUsername = username;
        this.registeredPassword = password;
        this.registeredCellPhone = cellPhoneNumber;

        return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";
    }

    /*
     * This method checks if the login details match what was registered.
     * I used .equals() instead of == because in Java, == compares memory
     * addresses for Strings, not the actual content.
     */
    public boolean loginUser(String username, String password) {
        if (registeredUsername == null || registeredPassword == null) return false;
        return registeredUsername.equals(username) && registeredPassword.equals(password);
    }

    /*
     * This method returns the appropriate message after a login attempt.
     * If login is successful it welcomes the user by name,
     * otherwise it tells them the details were incorrect.
     */
    public String returnLoginStatus(String username, String password) {
        if (loginUser(username, password)) {
            return "Welcome " + firstName + " " + lastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    /*
     * Main method - this is where the app actually runs.
     * I used Scanner so the user can type their own details in the console.
     * The app asks for registration details first, then lets the user log in.
     */
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        // Ask for first and last name to create the Login object
        System.out.println("===== WELCOME =====");
        System.out.print("Enter your first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter your last name: ");
        String lastName = scanner.nextLine();

        // Create the Login object with the user's name
        Login login = new Login(firstName, lastName);

        // ── REGISTRATION ──────────────────────────────────
        System.out.println("\n===== REGISTRATION =====");

        // Keep asking for username until they get it right
        String username = "";
        while (true) {
            System.out.print("Enter a username: ");
            username = scanner.nextLine();
            if (login.checkUserName(username)) {
                System.out.println("Username successfully captured.");
                break;
            } else {
                System.out.println("Username is not correctly formatted; please ensure that " +
                        "your username contains an underscore and is no more than five characters in length.");
            }
        }

        // Keep asking for password until they get it right
        String password = "";
        while (true) {
            System.out.print("Enter a password: ");
            password = scanner.nextLine();
            if (login.checkPasswordComplexity(password)) {
                System.out.println("Password successfully captured.");
                break;
            } else {
                System.out.println("Password is not correctly formatted; please ensure that the password " +
                        "contains at least eight characters, a capital letter, a number, and a special character.");
            }
        }

        // Keep asking for cell number until they get it right
        String cellPhone = "";
        while (true) {
            System.out.print("Enter your cell phone number (e.g. +27831234567): ");
            cellPhone = scanner.nextLine();
            if (login.checkCellPhoneNumber(cellPhone)) {
                System.out.println("Cell phone number successfully added.");
                break;
            } else {
                System.out.println("Cell number is incorrectly formatted or does not contain " +
                        "international code; please correct the number and try again.");
            }
        }

        // Register the user now that all details are valid
        login.registerUser(username, password, cellPhone);
        System.out.println("\nRegistration successful! You can now log in.");

        // ── LOGIN ──────────────────────────────────────────
        System.out.println("\n===== LOGIN =====");

        // Give the user 3 attempts to log in
        int attempts = 0;
        while (attempts < 3) {
            System.out.print("Enter your username: ");
            String enteredUsername = scanner.nextLine();

            System.out.print("Enter your password: ");
            String enteredPassword = scanner.nextLine();

            System.out.println(login.returnLoginStatus(enteredUsername, enteredPassword));

            // If login was successful, stop asking
            if (login.loginUser(enteredUsername, enteredPassword)) {
                break;
            }

            attempts++;

            // Tell them how many attempts they have left
            if (attempts < 3) {
                System.out.println("Attempts remaining: " + (3 - attempts));
            } else {
                System.out.println("Too many failed attempts. Please try again later.");
            }
        }

        scanner.close();
    }
}