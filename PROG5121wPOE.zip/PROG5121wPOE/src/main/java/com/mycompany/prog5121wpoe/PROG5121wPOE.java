/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog5121wpoe;

/**
 *
 * @author CC SUNNYSIDE
 */
public class PROG5121wPOE {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
